var usuarios= [];
var clients= new Array();
var Facturas= new Array();
var Trabajos= new Array();
var Chambas= Chambas ||{
	User: function (name, user, password, acceso) {
		this. name = name;
		this.user = user;
		this.password = password;
		this.acceso = acceso;
  },
  Client: function(name,id, phone ){
    this.name = name;
    this.id = id;
    this.phone = phone;
  },
  Factura: function(Client, descripcion, date, monto){
    this.Client = Client;
    this.descripcion = descripcion;
    this.date = date;
    this.monto = monto;
  },
  Trabajo: function(Client, descripcion, date, notes){
   this.Client = Client;
   this.descripcion = descripcion;
   this.date = date;
   this.notes;
 },
 Login: function (){
   var user = document.getElementById('UserName').value;
   var password = document.getElementById('Password').value;
   if (user == 'admin' && password == '$uper4dmin') {
    console.log(user, password);
    /*document.getElementById('login').action ="dashboard.html"*/
    location.href = "dashboard.html";
  }
  else 
  {
    alert("usuario incorrecto, Vuelva a intentar");
  };
},
ObtenerDatosUsuraio: function(){
  console.log("Hola1;")
  var nombre = document.getElementById("nameU").value;
  var user = document.getElementById("user").value;
  var password = document.getElementById("password").value;
  var rpassword = document.getElementById("passwordR").value;
  if (nombre == null || user == null || password == null || rpassword == null){
    alert("Por favor inserte todos los datos solicitados");
  }else{
    if (password === rpassword) {
      var usuario1 = new Chambas.User(nombre, user, password, "SuperAdmin");
	  if(JSON.parse(localStorage.getItem("usuarios")) == null){
		  var usuarios = [];
	  }else{
		  usuarios = JSON.parse(localStorage.getItem("usuarios"));
	  }
	  usuarios.push(usuario1);
      var us = JSON.stringify(usuarios);
      localStorage.setItem("usuarios", us);
      alert("S");
    }else{
      alert("Las contraseñas no coinciden");
    };
    /*document.getElementById("passwordR").setAttribute('value','My default value');*/
  };
},
MostrarUsuario: function(){

},
};